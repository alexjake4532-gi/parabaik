# Parabaik — deploying on Netlify

This folder is a ready-to-deploy site. The page (`index.html`) calls
`/api/translate`, which Netlify redirects to a serverless function
(`netlify/functions/translate.js`). The function holds your Anthropic API
key server-side and does the actual translation call, so the key is never
exposed in the browser.

## 1. Push this folder to GitHub

Create a new repo and push these files, keeping the folder structure as-is:

```
index.html
netlify.toml
netlify/functions/translate.js
```

## 2. Create the Netlify site

1. In Netlify: **Add new site → Import an existing project → connect GitHub**
   and pick the repo.
2. Build settings: leave **build command** empty and **publish directory**
   as `.` (root) — `netlify.toml` already sets this.
3. Deploy.

## 3. Add your API key

1. Get an API key from the [Anthropic Console](https://console.anthropic.com/).
2. In Netlify: **Site settings → Environment variables → Add a variable**.
   - Key: `ANTHROPIC_API_KEY`
   - Value: your key (starts with `sk-ant-...`)
3. Trigger a redeploy (Netlify → Deploys → Trigger deploy) so the function
   picks up the new variable.

## 4. Test it

Open your Netlify URL and translate something. If it fails, check
**Netlify → Functions → translate → logs** for the error — the function
returns a clear message if the API key is missing or invalid.

## Notes

- Each translation is a real Anthropic API call and will incur a small
  usage cost on your account. The function caps input at 2000 characters
  per request to keep costs predictable.
- If you'd rather not use your own API key, swap the function call back to
  a free public translation API — ask and I can put that version together.
