// Netlify Function: proxies translation requests to the Anthropic API.
// Keeps the API key server-side so it's never exposed to the browser.
//
// Requires an environment variable set in Netlify's site settings:
//   ANTHROPIC_API_KEY = sk-ant-...

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed.' }) };
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Server is missing ANTHROPIC_API_KEY. Add it in Netlify: Site settings > Environment variables.' })
    };
  }

  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON body.' }) };
  }

  const { text, fromName, toName } = payload;

  if (!text || !fromName || !toName) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Missing text, fromName, or toName.' }) };
  }
  if (typeof text !== 'string' || text.length > 2000) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Text must be a string of 2000 characters or fewer.' }) };
  }

  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 1000,
        system: 'You are a translation engine. Translate the text the user gives you as faithfully and naturally as possible. Reply with ONLY the translated text — no quotation marks, no notes, no explanations, no restating the original.',
        messages: [
          { role: 'user', content: `Translate this from ${fromName} to ${toName}:\n\n${text}` }
        ]
      })
    });

    if (!res.ok) {
      const detail = await res.text();
      return {
        statusCode: res.status,
        body: JSON.stringify({ error: 'Anthropic API returned an error.', detail })
      };
    }

    const data = await res.json();
    const translation = (data.content || [])
      .map((block) => (block.type === 'text' ? block.text : ''))
      .join('')
      .trim();

    if (!translation) {
      return { statusCode: 502, body: JSON.stringify({ error: 'No translation text returned.' }) };
    }

    return {
      statusCode: 200,
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ translation })
    };
  } catch (err) {
    return { statusCode: 502, body: JSON.stringify({ error: 'Request to Anthropic failed.' }) };
  }
};
